﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sarashaabani._._140212028005
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string infix = textBox1.Text;
            string prefix = ConvertInfixToPrefix(infix);
            textBox2.Text = prefix;
        }
        private string ConvertInfixToPrefix(string infix)
        {
            Stack<char> operators = new Stack<char>();
            Stack<string> operands = new Stack<string>();
            for (int i = infix.Length - 1; i >= 0; i--)
            {
                char c = infix[i];
                if (Char.IsLetterOrDigit(c))
                {
                    operands.Push(c.ToString());
                }
                else if (c == ')')
                {
                    operators.Push(c);
                }
                else if (c == '(')
                {
                    while (operators.Peek() != ')')
                    {
                        string operand1 = operands.Pop();
                        string operand2 = operands.Pop();
                        char op = operators.Pop();
                        string expression = op + operand1 + operand2;
                        operands.Push(expression);
                    }
                    operators.Pop();
                }
                else
                {
                    while (operators.Count > 0 && Precedence(c) < Precedence(operators.Peek()))
                    {
                        string operand1 = operands.Pop();
                        string operand2 = operands.Pop();
                        char op = operators.Pop();
                        string expression = op + operand1 + operand2;
                        operands.Push(expression);
                    }
                    operators.Push(c);
                }
            }
            while (operators.Count > 0)
            {
                string operand1 = operands.Pop();
                string operand2 = operands.Pop();
                char op = operators.Pop();
                string expression = op + operand1 + operand2;
                operands.Push(expression);
            }
            if (operands.Count > 0)
            {
                return operands.Pop();
            }
            else
            {
                return string.Empty;
            }
        }
        private int Precedence(char op)
        {
            switch (op)
            {
                case '+':
                case '-':
                    return 1;
                case '*':
                case '/':
                    return 2;
                case '^':
                    return 3;

            }
            return -1;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string prefix = textBox3.Text;
            string infix = ConvertPrefixToInfix(prefix);
            textBox4.Text = infix;
        }
        private string ConvertPrefixToInfix(string prefix)
        {
            Stack<string> stack = new Stack<string>();
            for (int i = prefix.Length - 1; i >= 0; i--)
            {
                char c = prefix[i];
                if (Char.IsLetterOrDigit(c))
                {
                    stack.Push(c.ToString());
                }
                else if (IsOperator(c))
                {
                    string operand1 = stack.Pop();
                    string operand2 = stack.Pop();
                    string expression = "(" + operand1 + c + operand2 + ")";
                    stack.Push(expression);
                }
            }
            return stack.Pop();
        }
        private bool IsOperator(char c)
        {
            return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
        }
    }
}
